/* snd.h - sndA, sndB */

/* Snd function prototypes */
void sndA(void);
void sndB(void);